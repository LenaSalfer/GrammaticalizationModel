module Model

using StatsBase
using Agents
using Random

export VariationalLearner
export speak!
export learn!
export interact!
export make_model


# ________________________________________________________
# Creating the 'Variational Learner' custom type

# Abstract type
abstract type VariationalLearner <: AbstractAgent end

# Variational learner type on a 2D grid
@agent struct GridVL(GridAgent{2}) <: VariationalLearner
  p::Float64            # probability of using the old usage pattern when talking about topic 1 (as opposed to alternative forms)
  q::Float64            # probability of using the new usage pattern when talking about topic 2 (as opposed to alternative forms)
  gamma::Float64        # the learning rate -> determines the speed of learning
  age::Int64            # age

  # Counters that track the agent's linguistic experience
  C_old::Float64        # counter for S_old strings (clearly old usage pattern)
  C_oldbridge::Float64  # counter for S_oldbridge strings (produced by the old usage pattern, but ambiguous on the surface)
  C_newbridge::Float64  # counter for S_newbridge strings (produced by the old usage pattern, but ambiguous on the surface)
  C_new::Float64        # counter for S_new strings (clearly new usage pattern)

  # Portions in the agent's linguistic representation
  P_old::Float64        # portion of S_old
  P_oldbridge::Float64  # portion of S_oldbridge
  P_newbridge::Float64  # portion of S_newbridge
  P_new::Float64        # portion of S_new

  # The following fields do not influence the agent's behavior - they are only used for tracking
  # Number of strings spoken (not perceived)
  S_old_alt::Int64      # number of S_old_alt (alternatives to the old usage pattern for talking about topic 1)
  S_old::Int64          # number of S_old
  S_bridge::Int64       # number of S_bridge (all ambiguous sentences: S_oldbridge & S_newbridge)
  S_new::Int64          # number of S_new
  S_new_alt::Int64      # number of S_new_alt (alternatives to the new usage pattern when talking about topic 2)
end



# ________________________________________________________
# Defining the functions for the model

# __________________________________________________________
# Helper functions for speak!() and learn!()

# Avoiding 0-division when calculating conditional probabilities (speak!)
function safe_P_cond(field1, field2)
  denominator = field1 + field2
  if denominator == 0
      return 0.0  
  else
      return (field1 / denominator)
  end
end


# Update the agent's linguistic representation = calculating the new proportions P_old etc. based on the counters C_old etc. (speak! & learn!)
function update_LR!(x::VariationalLearner)
  total = x.C_old + x.C_oldbridge + x.C_newbridge + x.C_new
  if total == 0
      x.P_old, x.P_oldbridge, x.P_newbridge, x.P_new = 0.0, 0.0, 0.0, 0.0
  else
      x.P_old = x.C_old / total
      x.P_oldbridge = x.C_oldbridge / total
      x.P_newbridge = x.C_newbridge / total
      x.P_new = x.C_new / total
  end
end


# Reward p and q according to Yang's (2000) penalty-reward-scheme (updateVL! & learn!)
function reward!(x::VariationalLearner, field::Symbol)
  if field == :p
    x.p = x.p + x.gamma * (1 - x.p)
    if x.p >= 0.999
      x.p = 1.0
    end
  else # field == :q
    x.q = x.q + x.gamma * (1 - x.q)
    if x.q >= 0.999
      x.q = 1.0
    end
  end
end


# Penalize p and q according to Yang's (2000) penalty-reward-scheme (updateVL! & learn!)
function penalize!(x::VariationalLearner, field::Symbol)
  if field == :p
    x.p = x.p - x.gamma * x.p
    if x.p <= 0.001
      x.p = 0.0
    end
  else # field == :q
    x.q = x.q - x.gamma * x.q 
    if x.q <= 0.001
      x.q = 0.0
    end
  end
end


# Update the speaker's counters and p + q values depending on the string they uttered (speak!)
function updateVL!(x::VariationalLearner, model, s::String)
  if s == "L_old_alt"
    penalize!(x, :p)
  elseif s == "L_old"
    x.C_old += 1
    reward!(x, :p)
  elseif s == "L_oldbridge"
    x.C_oldbridge += 1
    reward!(x, :p)
  elseif s == "L_newbridge"
    x.C_newbridge += model.alpha * 1
    reward!(x, :q)
  elseif s == "L_new"
    x.C_new += model.alpha * 1
    reward!(x, :q)
  else # s == "L_new_alt"
    penalize!(x, :q)
  end
end


# Track the speaker's uttered strings for the analysis (speak!)
function count_output!(x::VariationalLearner, s::String)
  if s == "L_old_alt"
    x.S_old_alt += 1
  elseif s == "L_old"
    x.S_old += 1
  elseif s == "L_oldbridge" || s == "L_newbridge"
    x.S_bridge += 1
  elseif s == "L_new"
    x.S_new += 1
  else # s == "L_new_alt"
    x.S_new_alt += 1
  end
end



# __________________________________________________________
# Core functions: speak & learn

# The speaker utters a sentence/string
function speak!(x::VariationalLearner, model)
  
  # Chosing a topic to talk about
  topic = sample(abmrng(model), ["Topic_1", "Topic_2"], Weights([0.5, 0.5]))

  # Topic 1
  # Chosing a linguistic form: UP_old or alternative forms
  if topic == "Topic_1"
    ling_form = sample(abmrng(model), ["UP_old", "alt_forms"], Weights([x.p, 1 - x.p]))
  
    if ling_form == "alt_forms" # Alternative form is chosen
      string = "L_old_alt"
    
    else # UP_old is chosen
        if (x.P_newbridge / x.P_oldbridge) > model.gricean_cap # Cutting off the production of ambiguous sentences after the ratio P_newbridge/P_oldbridge exceeded the gricean cap
          string = "L_old"
        else # gricean cap is not yet reached
          P_cond = safe_P_cond(x.P_old, x.P_oldbridge)
          string = sample(abmrng(model), ["L_old", "L_oldbridge"], Weights([P_cond, 1 - P_cond]))
        end
    end
   
  # Topic 2
  # Chosing a linguistic form: UP_new or alternative forms  
  else 
    ling_form = sample(abmrng(model), ["UP_new", "alt_forms"], Weights([x.q, 1 - x.q])) 
    if ling_form == "UP_new"

      # Conditions for innovation not fulfilled -> no innovation possible
      if x.C_newbridge < model.theta && x.C_new == 0  
        string = "L_newbridge"
    
       # Conditions for innovation fulfilled -> innovation possible
      elseif x.C_newbridge > model.theta && x.C_new == 0 
        decision = sample(abmrng(model), ["NoInnovation", "Innovation"], Weights([1 - model.P_I, model.P_I])) # Decide whether innovation happens
        if decision == "Innovation"
          string = "L_new"
        else # No innovation
          string = "L_newbridge"
        end
      
      # Speaker is already familiar with new grammar -> no need for innovation anymore
      else 
        P_Cond = safe_P_cond(x.P_new, x.P_newbridge)
        string = sample(abmrng(model), ["L_new", "L_newbridge"], Weights([P_Cond, 1 - P_Cond]))
      end

    else # Speaker uses an alternative form
      string = "L_new_alt"
    end
  end

  # Keeping track what sentence is uttered for the analysis
  count_output!(x, string)

  # Updating the speaker's counters and p & q
  updateVL!(x, model, string)
  update_LR!(x)
  return string
end



# Agent learns based on an input string (= the output of speak!)
function learn!(x::VariationalLearner, s::String, model)
  # Learner receives an unambiguous string
  if s == "L_old_alt"
    penalize!(x, :p)

  elseif s == "L_new_alt"
    penalize!(x, :q)

  elseif s == "L_old"
    reward!(x, :p)
    x.C_old += 1

  elseif s == "L_new"
    reward!(x, :q)
    x.C_new += model.alpha*1

  # Learner receives an ambiguous string
  else  
    #conditions for reanalysis fulfilled
    if x.C_newbridge == 0 && x.C_new == 0 
      decision = sample(abmrng(model), ["NoReanalysis", "Reanalysis"], Weights([1 - model.P_I, model.P_I])) # Decide whether reanalysis happens
        
      if decision == "Reanalysis"
        reward!(x, :q) 
        x.C_newbridge += model.alpha*1

      else  # No reanalysis
        reward!(x, :p)
        x.C_oldbridge += 1
      end

    # Agent is already familiar with new interpretation (reanalysis already happened or heard L_new from another speaker) -> no need for innovation
    else 
      grammar = sample(abmrng(model), ["UP_old", "UP_new"], Weights([(x.P_old + x.P_oldbridge), (x.P_new + x.P_newbridge)]))  
        if grammar == "UP_old"
          reward!(x, :p)
          x.C_oldbridge += 1
        else # UP_new
          reward!(x, :q)
          x.C_newbridge += model.alpha*1
        end
    end
  end
  # Updating the proportions within the learner's linguistic representation
  update_LR!(x)
  return x.p, x.q
end



# __________________________________________________________
# Functions for stepping the model

# Agent ages and eventually dies, getting replaced by a new born agent
function cycle_of_life!(x::VariationalLearner, model)
  # Aging
  x.age += 1

  # Dying
  max_age = model.max_age
  age_of_death = max_age

  if x.age >= age_of_death
    remove_agent!(x, model)

      add_agent_single!(model, 
                0.5,       # p = probability of using old usage of LS over alt forms
                0.5,       # q = probability of using new usage of LS over alt forms
                model.max_gamma,      # gamma = learning rate
                0,         # age
                0,         # C_old
                0,         # C_oldbridge
                0,         # C_newbridge
                0,         # C_new
                0.0,       # P_old
                0.0,       # P_oldbridge
                0.0,       # P_newbridge
                0.0,       # P_new
                0,         # S_old_alt
                0,         # S_old
                0,         # S_bridge
                0,         # S_new
                0          # S_new_alt
      )  
  end
end


# Updating the learning rate gamma -> dependent on the agent's age
function update_gamma!(x::VariationalLearner, model)
  x.gamma = model.max_gamma *exp((log(1/10)/model.max_age)*x.age)
end


# Two agents interact: x speaks, y listens
function interact!(x::VariationalLearner, y::VariationalLearner, model)
  s = speak!(x, model)
  learn!(y, s, model)
end


# Stepping function for the model, that contains: speaking & listening, updating gamma, living and dying
function VL_step!(agent::VariationalLearner, model)
    interlocutor = random_nearby_agent(agent, model)
      while interlocutor.age < (model.max_age / 7)      
       interlocutor = random_nearby_agent(agent, model)
      end
    interact!(interlocutor, agent, model)
    update_gamma!(agent, model)
    cycle_of_life!(agent, model)
end


# __________________________________________________________
# Model initialization

# Creating a model 
function make_model(;p::Float64, 
                    P_I::Float64, 
                    ambiguity::Float64, 
                    max_age::Int64, 
                    alpha::Float64, 
                    theta::Int64, 
                    max_gamma::Float64, 
                    seed::Int64, 
                    gricean_cap::Float64)
  
  # Setting the space
  dims = (10, 10)
  space = GridSpace(dims)

  # Setting the model
  model = StandardABM(
        GridVL,
        space,
        agent_step! = VL_step!,
        rng = Xoshiro(seed),
        properties = Dict(
          :max_age => max_age,
          :alpha => alpha,
          :theta => theta,
          :ambiguity => ambiguity,
          :p => p,
          :P_I => P_I,
          :seed => seed,
          :max_gamma => max_gamma,
          :gricean_cap => gricean_cap
        )
  )

  # Adding the agents
  for i in 1:100

    agent_age = rand(abmrng(model),0:max_age)
    gamma = max_gamma * exp((log(1/10) / max_age) * agent_age)

    initial_P_OB = ambiguity
    initial_P_O = 1 - ambiguity
    
    add_agent_single!(model, 
                p,                  # p = probability of using old usage of LF over alt forms
                0.0,                # q = probability of using new usage of LF over alt forms
                gamma,              # gamma = learning rate
                agent_age,          # age
                (initial_P_O*100),  # C_old
                (initial_P_OB*100), # C_oldbridge
                0,                  # C_newbridge
                0,                  # C_new
                initial_P_O,        # P_old
                initial_P_OB,       # P_oldbridge
                0.0,                # P_newbridge
                0.0,                # P_new
                0,                  # S_old_alt
                0,                  # S_old
                0,                  # S_bridge
                0,                  # S_new
                0                   # S_new_alt
    )    
  end

  return model
end



end

