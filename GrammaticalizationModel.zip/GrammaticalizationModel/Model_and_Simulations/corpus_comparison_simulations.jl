#===========================================
This file containsthe code to create the 
simulation data for the corpus comparison
============================================#


include("Model.jl")

using .Model
using Agents
using Random
using DataFrames
using CSV

# Create a model
model1 = make_model(
    p = 0.5, 
    P_I = 0.001,
    ambiguity= 0.2, 
    max_age = 30000, 
    alpha = 10.0, 
    theta = 100,
    max_gamma = 0.01,
    gricean_cap = 100.0,
    seed = 1)


adata1=[
        (:q, mean), 
        (:p, mean),
        (:P_old, mean), 
        (:P_oldbridge, mean),
        (:P_newbridge, mean),
        (:P_new, mean)
        ]
    
data, _ = run!(model1, 300000; adata1, when=((m,s)->s % 100 == 0))
CSV.write("../Data/corpus_comparison/P_counters.csv", data)



adata2 = [
    :p, 
    :q, 
    :S_old, 
    :S_bridge, 
    :S_new, 
    :S_new_alt
    ]

    
data, _ = run!(model1, 300000; adata2, when=((m,s)->s % 100 == 0))
CSV.write("../Data/corpus_comparison/S_counters.csv", data)



 


