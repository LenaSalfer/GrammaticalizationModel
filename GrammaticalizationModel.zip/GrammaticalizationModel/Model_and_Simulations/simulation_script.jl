
@everywhere begin
    include("Model.jl")

    using .Model
    using Agents
    using Random
    using DataFrames
    using Statistics
    using CSV 
    using JSON
    using Dates
    using Distributed
end


# Parameter set 1
parameters = Dict(
    :p => [0.5],                       
    :alpha => [1.0, 3.0, 5.0, 7.0, 10.0, 15.0],       
    :theta => [1, 50, 100, 500, 1000, 5000],                    
    :P_I => [0.001],                   
    :ambiguity => collect(0.0:0.2:1.0),                                             
    :max_age => [7000, 15000, 30000, 100000],               
    :max_gamma => [0.01],
    :gricean_cap => [1.0, 2.0, 10.0, 50.0, 100.0]     
) 

# Parameter set 2
#=
parameters = Dict(
    :p => [0.5],                       
    :alpha => [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 10.0, 15.0],       
    :theta => [100],                    
    :P_I => [0.001],                   
    :ambiguity => collect(0.0:0.1:1.0),                                             
    :max_age => [7000, 30000],               
    :max_gamma => [0.01],
    :gricean_cap => [100.0]     
) 
=#
    
# Parameter set 3
#=
parameters = Dict(
    :p => collect(0.0:0.1:1.0),                       
    :alpha => [1.0, 3.0, 5.0, 7.0, 10.0, 15.0],       
    :theta => [100],                    
    :P_I => [0.0001, 0.001, 0.01, 0.1],                   
    :ambiguity => collect(0.0:0.2:1.0),                                             
    :max_age => [30000],               
    :max_gamma => [0.01],
    :gricean_cap => [100.0]     
) 
=#

# Data to collect 
adata = [
    (:p, mean),
    (:q, mean),
    (:P_old, mean),
    (:P_oldbridge, mean),
    (:P_newbridge, mean),
    (:P_new, mean)
  ]


# Modified agents::paramscan function that takes a RNG seed as argument
# Is used in the simulate function below
@everywhere function paramscan_seed(;seed::Int64, steps::Int64, parameters, adata)

    local_params = copy(parameters)  
    local_params[:seed] = [seed]    

    df, _ = paramscan(
        local_params,           
        Model.make_model;    # Model initialization function
        adata,                
        n = steps,           # Number of steps per simulation
        when=((m,s)->s % 100 == 0)  # Collect data only every 100th timestep
    )

    return df
end


# Conduct parameter sweeps and save the data
# steps = time steps in one simulation
# runs = number of parameter sweeps to collect (each with a different RNG seed from 1 to *number of runs*)
# Can be run in parallel over multiple CPU cores, if multiple working processes of julia are instantiated
function simulate(;steps::Int64, runs::Int64)
    println("Running in parallel...")

    # Generate a run ID to keep the simulation data files organized
    run_id = Dates.format(now(), "yyyy-mm-dd_HH-MM-SS")

    time0 = time()
  
    # Conduct parameter sweeps 
    results = @sync @distributed (vcat) for i in 1:runs
        df = paramscan_seed(;
                seed = i,
                steps = steps,
                parameters = parameters,
                adata = adata)

        # Define unique filename for each run
        filename_run = "paramscan_$(run_id)_run$(i).csv"

        # Save each run (= 1 sweep over all parameters for 1 RNG seed)
        CSV.write(filename_run, df)

        println("Saved intermediate result to: $filename_run")

        df  
    end
  
    delta = time() - time0
    println("Runtime: $delta seconds")


    # Generate metadata
    filename_metadata = "paramscan_$(run_id)_metadata.json"
    metadata = Dict(
        "run_id" => run_id,
        "date" => Dates.format(now(), "yyyy-MM-dd HH:MM:SS"),
        "steps" => steps,
        "runs" => runs,
        "parameters" => parameters
    )

    # Safe metadata in JSON file
    open(filename_metadata, "w") do f
        JSON.print(f, metadata) 
    end

    println("Metadata saved to: $filename_metadata")
  
    return results
end
