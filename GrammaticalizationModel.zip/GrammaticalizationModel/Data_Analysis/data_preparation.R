# ------------------------------------
# Prepare the raw data:
# Filter data &
# Calculate measures for the analysis
# ------------------------------------

library(tidyverse)


# Define the directories
# AI help
input_dir <- "../data/raw/parameter_set1"
output_dir <- "../data/processed/parameter_set1"

# List all files from the input directory
# AI help
files <- list.files(
  path = input_dir, 
  pattern = "\\.csv$",  
  recursive = TRUE, 
  full.names = TRUE
)


# Execute changes for all simulation files
# AI help (for loop and automatic saving only)
for (file in files) {
  cat("Processing:", file, "\n")
  
  # Load the file
  df <- read_csv(file, show_col_types = FALSE)
  
  # Prepare data and calculate extra measures for analysis.
  df_prepared <- df %>%
    mutate(across(c(ambiguity, alpha, max_age, theta, p, P_I, max_gamma, gricean_cap, seed), as.factor)) %>%
    group_by(max_age, alpha, ambiguity, theta, p, P_I, max_gamma, gricean_cap, seed) %>%  # include seed!
    arrange(time) %>% 
    mutate(
      UP_new    = (mean_P_newbridge + mean_P_new),          # Value of new UP
      UP_new_max = max(UP_new, na.rm = TRUE),                # Maximum new UP 
      UP_ratio = if_else(mean_P_oldbridge + mean_P_old != 0, 
                         (mean_P_newbridge + mean_P_new)/(mean_P_oldbridge + mean_P_old), 
                         NA_real_
                         ), # Ratio of UP_new / UP_old
      row_mid_reached = UP_ratio > 1, # Boolean: Midpoint of grammaticalization reached? (per row)
      
      # Calculate the midpoint time
      midpoint_time = if_else(any(row_mid_reached), first(time[row_mid_reached]), NA_real_),
      
      # Calculate the endpoint time
      endpoint_time = if_else(!is.na(midpoint_time), 2 * midpoint_time, NA_real_)
    ) %>%
    ungroup()
  
  # Summarize calculated values for each unique parameter combination.
  df_summary <- df_prepared %>%
    group_by(max_age, alpha, ambiguity, theta, p, P_I, max_gamma, gricean_cap, seed) %>%
    summarize(
      UP_new_max   = first(UP_new_max),
      midpoint_time = first(midpoint_time),  
      endpoint_time = first(endpoint_time),
      max_p        = first(max(mean_p, na.rm = TRUE)),
      min_p        = first(min(mean_p, na.rm = TRUE)),
      max_q        = first(max(mean_q, na.rm = TRUE)),
      min_q        = first(min(mean_q, na.rm = TRUE)),
      max_p_time   = first(time[which.max(mean_p)]),
      min_p_time   = first(time[which.min(mean_p)]),
      max_q_time   = first(time[which.max(mean_q)]),
      min_q_time   = first(time[which.min(mean_q)]),
      .groups = "drop"
    ) %>% 
    # Create column midpoint_reached: TRUE if midpoint_time is not NA.
    mutate(midpoint_reached = !is.na(midpoint_time))
  
  # Retrieve midpoint data
  midpoint_data <- df_prepared %>%
    filter(!is.na(midpoint_time) & time == midpoint_time) %>% 
    select(max_age, alpha, ambiguity, theta, p, P_I, max_gamma, gricean_cap, seed,
           mid_UP_ratio = UP_ratio,  # UP_ratio at midpoint
           mid_p = mean_p, # p value at midpoint
           mid_q = mean_q) # q value at midpoint
  
  # Retrieve endpoint data
  endpoint_data <- df_prepared %>%
    filter(!is.na(endpoint_time) & time == endpoint_time) %>%
    select(max_age, alpha, ambiguity, theta, p, P_I, max_gamma, gricean_cap, seed,
           end_UP_ratio = UP_ratio, # UP_ratio at endpoint
           end_p = mean_p, # p value at endpoint
           end_q = mean_q) # q value at endpoint

  
  # Join the dataframes containing the summarized data, midpoint data and endpoint data
  final_df <- df_summary %>%
    left_join(midpoint_data, by = c("max_age", "alpha", "ambiguity", "theta", "p", "P_I", "max_gamma", "gricean_cap", "seed")) %>%
    left_join(endpoint_data, by = c("max_age", "alpha", "ambiguity", "theta", "p", "P_I", "max_gamma", "gricean_cap", "seed")) %>%
    mutate(speed = if_else(!is.na(midpoint_time), (1 / midpoint_time) * 500000, NA_real_))

  
  # Save the processed data file
  output_file <- file.path(output_dir, paste0("processed_", basename(file)))
  write_csv(final_df, output_file)
  
  cat("Saved:", output_file, "\n")
}

