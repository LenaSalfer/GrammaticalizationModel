# ---------------------------------------
# Heatmaps for parameter set 2
# ---------------------------------------

library(ggplot2)
library(tidyverse)
library(scales)  
library(viridis)


# Load data
df <- read_csv("Data/heatmap_data/heatmap_set2.csv")

# Define output directory
# AI help
output_dir <- "Data_Analysis/Simulation_Analysis/Simulation_Plots/Heatmaps/heatmaps_set2"


# --------------------------------------------------
# Crating the Heatmaps
# --------------------------------------------------


# Define a custom theme.
custom_theme <- function() {
  theme_light() +
    theme(
      plot.title = element_text(size = 18, face = "bold"),
      plot.subtitle = element_text(size = 16),
      axis.title.x = element_text(size = 16, margin = margin(t = 10)),
      axis.title.y = element_text(size = 16, margin = margin(r = 15)),
      axis.text.x = element_text(size = 12),
      axis.text.y = element_text(size = 12),
      legend.title = element_text(size = 16),
      legend.text = element_text(size = 14),
      legend.key.size = unit(0.8, "cm"),
      strip.background = element_rect(fill = "white", color = "black"),
      strip.text = element_text(size = 14, color = "black"),
      strip.text.x = element_text(angle = 0, hjust = 0.5, size = 12),
      strip.text.y = element_text(angle = 270, hjust = 0.5, size = 12)
    )
}




# Function to create and save heatmaps
# AI help for function creation & automatic saving
create_heatmaps_midpointNA <- function(df, max_age_value) {
  
  df_filtered <- df %>% filter(max_age == max_age_value)
  
  # Heatmap q at the endpoint
  heatmap_endq <- df_filtered %>% 
    ggplot(mapping = aes(x = factor(alpha), y = factor(ambiguity), fill = end_q)) +
    geom_tile() +
    xlab(expression(alpha)) + ylab("ambiguity") +
    custom_theme() +
    scale_fill_gradientn(
      name = "q endpoint",
      colors = c("white", "lightblue", "dodgerblue2", "blue", "midnightblue"), 
      values = scales::rescale(c(0, 0.1, 0.2, 0.4, 0.6)),  
      na.value = "#D3D8E0") +
    geom_text(aes(label = ifelse(NA_midpoint_time > 0, as.character(NA_midpoint_time), "")), #AI help
              color = "black", size = 4, fontface = "bold")
  
  ggsave(filename = file.path(output_dir, paste0("heatmap_endq_max_age_", max_age_value, "_2.png")),
         plot = heatmap_endq,width = 6, height = 6)
  
  
  # Heatmap p at the endpoint
  heatmap_endp <- df_filtered %>% 
    ggplot(mapping = aes(x = factor(alpha), y = factor(ambiguity), fill = end_p)) +
    geom_tile() +
    xlab(expression(alpha)) + ylab("ambiguity") +
    custom_theme() +
    scale_fill_gradientn(
      name = "p endpoint",
      colors = c("white", "#FFCCCC", "#FF6666", "#DC143C", "#8B0000"),  
      values = scales::rescale(c(0, 0.05, 0.1, 0.3, 0.5)), 
      na.value = "#D3D8E0") +
    geom_text(aes(label = ifelse(NA_midpoint_time > 0, as.character(NA_midpoint_time), "")), 
              color = "black", size = 4, fontface = "bold")
  
  ggsave(filename = file.path(output_dir, paste0("heatmap_endp_max_age_", max_age_value, "_2.png")),
         plot = heatmap_endp, width = 6, height = 6)
  
  
  # Heatmap grammaticalization speed
  heatmap_speed <- df_filtered %>% 
    ggplot(mapping = aes(x = factor(alpha), y = factor(ambiguity), fill = speed)) +
    geom_tile() +
    xlab(expression(alpha)) + ylab("ambiguity") +
    custom_theme() +
    scale_fill_gradientn(
      colors = rev(heat.colors(5)), 
      values = rescale(c(1, 7, 15, 30, 50, 75)),
      na.value = "#D3D8E0") +
    geom_text(aes(label = ifelse(NA_midpoint_time > 0, as.character(NA_midpoint_time), "")), 
              color = "black", size = 4, fontface = "bold")
  
  ggsave(filename = file.path(output_dir, paste0("heatmap_speed_max_age_", max_age_value, "_2.png")),
         plot = heatmap_speed, width = 6, height = 6)
  
  
  # Heatmap UP ratio at the endpoint
  plot_UP_ratio <- df_filtered %>% 
    ggplot(mapping = aes(x = factor(alpha), y = factor(ambiguity), fill = end_UP_ratio)) +
    geom_tile() +
    xlab(expression(alpha)) + ylab("ambiguity") +
    custom_theme() +
    scale_fill_gradientn(
      name = "UP ratio",
      colors = rev(plasma(5)),
      values = rescale(c(1, 7, 15, 30, 50, 70)),
      na.value = "#D3D8E0"
    ) +
    geom_text(aes(label = ifelse(NA_midpoint_time > 0, as.character(NA_midpoint_time), "")), 
              color = "black", size = 4, fontface = "bold")
  
  ggsave(filename = file.path(output_dir, paste0("heatmap_UPratio_max_age_", max_age_value, "_2.png")),
         plot = plot_UP_ratio, width = 6, height = 6)
}




# Loop through distinct max_age values and create heatmaps for each
# AI help
distinct_max_age_values <- df %>% distinct(max_age) %>% pull(max_age)

for (max_age_value in distinct_max_age_values) {
  create_heatmaps_midpointNA(df, max_age_value)
}

