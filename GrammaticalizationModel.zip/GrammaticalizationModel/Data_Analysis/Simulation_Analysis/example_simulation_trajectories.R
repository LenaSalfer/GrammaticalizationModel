# ---------------------------------------
# Plotting example simulation trajectories
# ---------------------------------------

library(tidyverse)
library(ggplot2)
library(cowplot)


# Loading the data
# To create trajectories over all time steps, the raw data is needed
read_csv("Data/raw/paramscan_2025-03-10_19-05-49_run1.csv") -> df

# Filtering a successful example
df_success <- df %>%
  filter(
    alpha == 8.0,
    ambiguity == 0.2,
    max_age == 30000,
    time < 500000
  )

# Filtering a unsuccessful example
df_NOsuccess <- df %>%
  filter(
    alpha == 1.0,
    ambiguity == 0.2,
    max_age == 30000,
    time < 500000
  )



# Creating a custom theme for plotting
custom_theme <- function() {
  theme_light() +
    theme(plot.title = element_text(size=28),
          legend.title = element_text(size=22),
          legend.text = element_text(size=16),
          legend.position = "top",
          axis.title.x = element_text(size=16, margin = margin(t = 10)),   
          axis.title.y = element_text(size=16, margin = margin(r = 15)), 
          axis.text.x = element_text(size=14),    
          axis.text.y = element_text(size=14),
          plot.background  = element_rect(fill = "white", color = NA),
          panel.background = element_rect(fill = "white", color = NA)
    ) 
}



# ---------------------------------------
# Plotting a successful example

df_success %>%
  ggplot(aes(x = time)) +
  geom_line(aes(y = mean_p, color = "p")) +
  geom_line(aes(y = mean_q, color = "q")) +
  scale_color_manual(
    name = "",
    values = c("p" = "#ff0000ff", "q" = "#0500ffff"),
    labels = c("p" = "p", "q" = "q")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> upper_plot


df_success %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = mean_P_old, color = "P_old")) + 
  geom_line(aes(y = mean_P_oldbridge + mean_P_newbridge, color = "P_oldbridge + P_newbridge")) +
  geom_line(aes(y = mean_P_new, color = "P_new")) +
  scale_color_manual(
    name = "",
    values = c("P_old" = "#ff0000ff", "P_oldbridge + P_newbridge" = "#aa00fffc", "P_new" = "#0500ffff"),
    labels = c("P_old" = "old contexts", "P_oldbridge + P_newbridge" = "bridging contexts", "P_new" = "new contexts")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  theme(plot.margin = unit(c(1, 0, 0, 0), "cm")) +
  custom_theme() -> lower_plot


plot_grid(upper_plot, lower_plot, labels = c("A","B"), ncol = 1, nrow = 2) -> traj_successful

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/trajectory_successful.png", plot = traj_successful)



# ---------------------------------------
# Plotting an unsuccessful example

df_NOsuccess %>%
  ggplot(aes(x = time)) +
  geom_line(aes(y = mean_p, color = "p")) +
  geom_line(aes(y = mean_q, color = "q")) +
  scale_color_manual(
    name = "",
    values = c("p" = "#ff0000ff", "q" = "#0500ffff"),
    labels = c("p" = "p", "q" = "q")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> upper_plot


df_NOsuccess %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = mean_P_old, color = "P_old")) + 
  geom_line(aes(y = mean_P_oldbridge + mean_P_newbridge, color = "P_oldbridge + P_newbridge")) +
  geom_line(aes(y = mean_P_new, color = "P_new")) +
  scale_color_manual(
    name = "",
    values = c("P_old" = "#ff0000ff", "P_oldbridge + P_newbridge" = "#aa00fffc", "P_new" = "#0500ffff"),
    labels = c("P_old" = "old contexts", "P_oldbridge + P_newbridge" = "bridging contexts", "P_new" = "new contexts")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  theme(plot.margin = unit(c(1, 0, 0, 0), "cm")) +
  custom_theme() -> lower_plot


plot_grid(upper_plot, lower_plot, labels = c("A","B"), ncol = 1, nrow = 2) -> traj_unsuccessful

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/trajectory_unsuccessful.png", plot = traj_unsuccessful)





# ----------------------------------------------------------------------------
# Creating a plot to exemplify the midpoint & endpoint of grammaticalization


df_success %>%
  ggplot(aes(x = time)) +
  geom_line(aes(y = mean_p, color = "p")) +
  geom_line(aes(y = mean_q, color = "q")) +
  scale_color_manual(
    name = "",
    values = c("p" = "#ff0000ff", "q" = "#0500ffff"),
    labels = c("p" = "p", "q" = "q")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> upper_plot
upper_plot

midpoint <- df_success %>%
  filter((mean_P_newbridge + mean_P_new) / (mean_P_oldbridge + mean_P_old) > 1) %>%
  slice(1) %>%
  pull(time)

df_success %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = mean_P_old, color = "P_old")) + 
  geom_line(aes(y = mean_P_oldbridge, color = "P_oldbridge")) +
  geom_line(aes(y = mean_P_newbridge, color = "P_newbridge")) +
  geom_line(aes(y = mean_P_new, color = "P_new")) +
  geom_vline(xintercept = midpoint, linetype = "dashed", color = "black") +
  annotate("text", x = (midpoint - 20000), y = 0.9, label = "midpoint", vjust = -1, color = "black", size = 4) +
  geom_vline(xintercept = 2*midpoint, linetype = "dashed", color = "black") +
  annotate("text", x = (2*midpoint - 20000), y = 0.9, label = "endpoint", vjust = -1, color = "black", size = 4) +
  scale_color_manual(
    name = "",
    values = c("P_old" = "#ff0000ff", "P_oldbridge" = "#ff00a2ff", "P_newbridge" = "#8a00ffff", "P_new" = "#0500ffff"),
    labels = c("P_old" = expression(P[old]), "P_oldbridge" = expression(P[oldbridge]), "P_newbridge" = expression(P[newbridge]), "P_new" = expression(P[new])),
    breaks = c("P_old", "P_oldbridge", "P_newbridge", "P_new")
  ) +
  xlab("simulation time steps") +
  ylab("population average") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  theme(plot.margin = unit(c(1, 0, 0, 0), "cm")) +
  custom_theme() -> lower_plot

plot_grid(upper_plot, lower_plot, labels = c("A","B"), ncol = 1, nrow = 2) -> traj_midpoint_endpoint
traj_midpoint_endpoint

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/trajectory_midpoint_endpoint.png", plot = traj_midpoint_endpoint)

