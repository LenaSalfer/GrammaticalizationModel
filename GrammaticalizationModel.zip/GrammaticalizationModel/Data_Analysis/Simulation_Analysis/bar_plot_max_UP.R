# ---------------------------------------
# Create the bar plot (Figure 10)
# of the max. UP ratio reaches in all
# simulations
# ---------------------------------------

library(tidyverse)
library(ggplot2)



# Define the path to the main folder
main_folder <- "Data/processed"

# Find all CSV files that start with "reshaped_paramscan" in the subdirectories
# AI help
csv_files <- list.files(path = main_folder, 
                        pattern = "^processed_paramscan.*\\.csv$",  
                        recursive = TRUE, 
                        full.names = TRUE)



# Join all files into one dataframes and remove duplicates
# AI help

combined_df <- csv_files %>%
  map_dfr(read_csv, .id = "source")

combined_df <- combined_df %>% 
  distinct(across(-source), .keep_all = TRUE)




#---------------------------------------------
# Create the bar plot


# Categorize the data for the bar plot
combined_df %>% 
  mutate(UP_new_max_category = case_when(
    UP_new_max <= 0.1 ~ "0 - 10%",
    UP_new_max > 0.1 & UP_new_max <= 0.2 ~ "10 - 20%",
    UP_new_max > 0.2 & UP_new_max <= 0.3 ~ "20 - 30%",
    UP_new_max > 0.3 & UP_new_max <= 0.4 ~ "30 - 40%",
    UP_new_max > 0.4 & UP_new_max <= 0.5 ~ "40 - 50%",
    UP_new_max > 0.5 & UP_new_max <= 0.6 ~ "50 - 60%",
    UP_new_max > 0.6 & UP_new_max <= 0.7 ~ "60 - 70%",
    UP_new_max > 0.7 & UP_new_max <= 0.8 ~ "70 - 80%",
    UP_new_max > 0.8 & UP_new_max <= 0.9 ~ "80 - 90%",
    UP_new_max > 0.9 & UP_new_max <= 1.0 ~ "90 - 100%"
  )) -> df_UP


# Create the plot
df_UP %>%
  ggplot(aes(x = UP_new_max_category, fill = UP_new_max_category)) +
  geom_bar() +
  labs(
    x = expression(paste("Max. % of ", UP[new], " (population average)")),
    y = "Number of simulations"
  ) +
  theme_light() +
  theme(
    plot.title = element_text(size = 18, face = "bold"), 
    plot.subtitle = element_text(size = 16), 
    axis.title.x = element_text(size = 16, margin = margin(t = 10)),
    axis.title.y = element_text(size = 16, margin = margin(r = 15)),
    axis.text.x = element_text(size = 14), 
    axis.text.y = element_text(size = 14), 
    legend.position = "none") -> UP_bar


ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/UP_bar.png", plot = UP_bar, height=6, width=10)


