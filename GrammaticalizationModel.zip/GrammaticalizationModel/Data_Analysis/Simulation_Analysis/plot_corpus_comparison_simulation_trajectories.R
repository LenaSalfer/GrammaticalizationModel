# ---------------------------------------
# Plotting simulation trajectories for 
# the corpus comparison
# ---------------------------------------

library(tidyverse)
library(ggplot2)
library(cowplot)


# Loading the data

read_csv("Data/corpus_comparison/final_mean_P.csv") -> df_P
read_csv("Data/corpus_comparison/final_individual_S.csv") -> df_indiv_S


# --------------------------------------------------
# Preparing the data
# --------------------------------------------------

# Preparation step:
# Calculating how many sentences of each type are added in each simulation step per agent
df_indiv_S <- df_indiv_S %>%
  group_by(id) %>%
  mutate(
    delta_S_old = if_else(S_old == 0, 0, S_old - lag(S_old)),
    delta_S_bridge = if_else(S_bridge == 0, 0, S_bridge - lag(S_bridge)),
    delta_S_new = if_else(S_new == 0, 0, S_new - lag(S_new)),
    delta_S_new_alt = if_else(S_new_alt == 0, 0, S_new_alt - lag(S_new_alt))
  ) %>%
  arrange(id)


# Calculating the relative frequencies
indiv_relative <- indiv_sum %>%
  mutate(
    S_total_gram = delta_S_old + delta_S_bridge + delta_S_new,
    gram_S_old = delta_S_old/S_total_gram,
    gram_S_bridge = delta_S_bridge/S_total_gram,
    gram_S_new = delta_S_new/S_total_gram
  ) %>%
  mutate(
    S_total_comp = delta_S_new + delta_S_new_alt,
    comp_S_new = if_else(delta_S_new == 0, 0, delta_S_new / S_total_comp),
    comp_S_new_alt = if_else(delta_S_new_alt == 0, 0, delta_S_new_alt / S_total_comp)
  )



# --------------------------------------------------
# Creating the plots
# --------------------------------------------------


custom_theme <- function() {
  theme_light() +
    theme(plot.title = element_text(size=28),
        legend.title = element_text(size=22),
        legend.text = element_text(size=18),
        legend.position = "top",
        axis.title.x = element_text(size=17, margin = margin(t = 10)),   
        axis.title.y = element_text(size=17, margin = margin(r = 15)), 
        axis.text.x = element_text(size=15),    
        axis.text.y = element_text(size=15),
        strip.background = element_rect(fill = "white", color = "black"),
        strip.text = element_text(size = 14, color = "black"),
        legend.key.size = unit(0.8, "cm")
  ) 
}



# ------------------------------------------------------------
# The trajectory of the relative frequencies of the S counters

indiv_relative %>%
  filter(time != 0) %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = gram_S_old, color = "S_old")) + 
  geom_line(aes(y = gram_S_bridge, color = "S_bridge")) +
  geom_line(aes(y = gram_S_new, color = "S_new")) +
  scale_color_manual(
    name = "",
    values = c("S_old" = "#ff0000ff", "S_bridge" = "#aa00fffc", "S_new" = "#0500ffff"),
    labels = c("S_old" = expression(S[old]),
               "S_bridge" = expression(S[bridge]),
               "S_new" = expression(S[new])),
    breaks = c("S_old", "S_bridge", "S_new")
  ) +
  xlab("simulation time steps") +
  ylab("relative frequency (population average)") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> S_counters_gram_patterns

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/S_counters_gram_patterns.png", plot = S_counters_gram_patterns, height=6, width=9)



# Second plot stored in the object 'unten'
indiv_relative %>%
  filter(time != 0) %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = comp_S_new, color = "S_new")) +
  geom_line(aes(y = comp_S_new_alt, color = "S_new_alt")) +
  scale_color_manual(
    name = "",
    values = c("S_new" = "#0500ffff", "S_new_alt" = "#33a1ffff"),
    labels = c(
               "S_new" = expression(S[new]),
               "S_new_alt" = expression(S[new-alt])),
  ) +
  xlab("simulation time steps") +
  ylab("relative frequency (population average)") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> S_counters_future_comparison

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/S_counters_future_comparison.png", plot = S_counters_future_comparison, height=6, width=9)




# ------------------------------------------------
# As comparison: The trajectory of the P counters

df_P %>%
  filter(time < 300000) %>%
  ggplot(aes(x = time)) + 
  geom_line(aes(y = mean_P_old, color = "P_old")) + 
  geom_line(aes(y = mean_P_oldbridge + mean_P_newbridge, color = "P_oldbridge + P_newbridge")) +
  geom_line(aes(y = mean_P_new, color = "P_new")) +
  scale_color_manual(
    name = "",
    values = c("P_old" = "#ff0000ff", "P_oldbridge + P_newbridge" = "#aa00fffc", "P_new" = "#0500ffff"),
    labels = c("P_old" = expression(P[old]),
               "P_oldbridge + P_newbridge" = expression(P[oldbridge] ~ + ~ P[newbridge]),
               "P_new" = expression(P[new])),
    breaks = c("P_old", "P_oldbridge + P_newbridge", "P_new")
  ) +
  xlab("simulation time steps") +
  ylab("percentage (population mean)") +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  custom_theme() -> P_counters

ggsave("Data_Analysis/Simulation_Analysis/Simulation_Plots/P_counters_corpus_comparison.png", plot = P_counters, height=6, width=9)


