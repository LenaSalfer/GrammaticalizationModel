# ---------------------------------------
# Heatmaps for parameter set 3
# ---------------------------------------

library(ggplot2)
library(tidyverse)
library(scales)  
library(viridis)


# Load data
df <- read_csv("Data/heatmap_data/heatmap_set3.csv")

# Define output directory
# AI help
output_dir <- "Data_Analysis/Simulation_Analysis/Simulation_Plots/Heatmaps/heatmaps_set3"


# --------------------------------------------------
# Preparing the data for plotting
# --------------------------------------------------


# Excluding some of the initial p values to make the grids smaller
df <- df %>%
  filter(
    p %in% c(0.1, 0.3, 0.5, 0.7, 0.9, 1.0)
  )


# Labelling and ordering the data for nice looking heatmap grids
# AI help
df <- df %>%
  mutate(
    P_I_ordered = factor(P_I, 
                         levels = c(0.0001, 0.001, 0.01, 0.1),
                         labels = c("P[I] == 0.0001", "P[I] == 0.001", 
                                    "P[I] == 0.01", "P[I] == 0.1")),
    p_ordered = factor(p,
                       levels = rev(sort(unique(p))), 
                       labels = paste0("p == ", rev(sort(unique(p)))))
    )




# --------------------------------------------------
# Crating the Heatmaps Grids
# --------------------------------------------------


# Define a custom theme.
custom_theme <- function() {
  theme_light() +
    theme(
      plot.title = element_text(size = 18, face = "bold"),
      plot.subtitle = element_text(size = 16),
      axis.title.x = element_text(size = 16, margin = margin(t = 10)),
      axis.title.y = element_text(size = 16, margin = margin(r = 15)),
      axis.text.x = element_text(size = 12),
      axis.text.y = element_text(size = 12),
      legend.title = element_text(size = 16, margin = margin(b = 15)),
      legend.text = element_text(size = 14),
      legend.key.size = unit(0.8, "cm"),
      strip.background = element_rect(fill = "white", color = "black"),
      strip.text = element_text(size = 14, color = "black"),
      strip.text.x = element_text(angle = 0, hjust = 0.5, size = 12),
      strip.text.y = element_text(angle = 270, hjust = 0.5, size = 12)
    )
}


# --------------------------------------------------
# Heatmap Grids

# Heatmaps: Ambiguity & alpha
# Grid for innovation prob. & initial p
# --------------------------------------------------


# -------------------------------------------------
# Heatmap Grids for grammtaicalization speed

# Modifying the data so that extremely high speed values are colored differently in the plot
# AI help
df_mod <- df %>%
  mutate(
    speed_flag = case_when(
      is.na(speed)   ~ "NA",           # Original NA values remain NA
      speed > 1000     ~ "out_of_range", # Mark out-of-range values
      TRUE           ~ "in_range"      # Values within the valid range
    ),
    speed_in_range = if_else(speed_flag == "in_range", speed, NA_real_)
  )



plot <- df_mod %>%
  ggplot(aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(data = df_mod %>% filter(speed_flag == "in_range"),
              aes(fill = speed_in_range)) +
    geom_tile(data = df_mod %>% filter(is.na(speed)),
              fill = "#D3D8E0") +
    geom_tile(data = df_mod %>% filter(speed_flag == "out_of_range"),
              fill = "darkred") +
    scale_fill_gradientn(
      colors = rev(heat.colors(10)),
      values = scales::rescale(c(1, 10, 20, 35, 50, 65, 75, 85, 100, 120, 135, 150)),
      limits = c(1, 1000),
      trans = "log",
      breaks = c(1, 10, 100)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "Speed"
    ) +
    facet_grid(p_ordered ~ P_I_ordered, labeller = label_parsed) + #AI help
    scale_y_discrete(
      limits = c("0", "0.2", "0.4", "0.6", "0.8", "1"),
      breaks = c("0", "1"),
      labels = c("0", "1")
    ) +
    custom_theme()
  
  file_name <- file.path(output_dir, "heatmap_speed_3.png")
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)


  
# -------------------------------------------------
# Heatmap Grids for UP_ratio at the endpoint
  
plot <- df %>% 
  ggplot(aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_UP_ratio)) +
    geom_tile(data = df %>% filter(is.na(end_UP_ratio)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = rev(plasma(5)),
      values = scales::rescale(c(2, 20, 50, 80, 120)),
      #limits = c(1, 100),
      trans = "log",
      breaks = c(1, 10, 100)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "UP ratio"
    ) +
    facet_grid(p_ordered ~ P_I_ordered, labeller = label_parsed) +
    scale_y_discrete(
      limits = c("0", "0.2", "0.4", "0.6", "0.8", "1"),
      breaks = c("0", "1"),
      labels = c("0", "1")
    ) +
    custom_theme()
  
  file_name <- file.path(output_dir, "heatmap_UPratio_3.png")
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  



# -------------------------------------------------
# Heatmap Grids for p at the endpoint
  
plot <- df %>%
  ggplot(aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_p)) +
    geom_tile(data = df %>% filter(is.na(end_p)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = c("white", "#FFCCCC", "#FF9999", "#FF6666", "#FF3333", "#DC143C", "#B22222", "#8B0000"),
      values = scales::rescale(c(0, 0.05, 0.1, 0.3, 0.3, 0.5, 0.7, 1.0)), 
      limits = c(0, 1.0),
      breaks = c(0.0, 0.25, 0.5, 0.75, 1.0)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "p endpoint"
    ) +
    facet_grid(p_ordered ~ P_I_ordered, labeller = label_parsed) +
    scale_y_discrete(
      limits = c("0", "0.2", "0.4", "0.6", "0.8", "1"),
      breaks = c("0", "1"),
      labels = c("0", "1")
    ) +
    scale_x_discrete(
      breaks = levels(factor(df$alpha))
    ) +
    custom_theme()
  
  file_name <- file.path(output_dir, "heatmap_endp_3.png")
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  

  
# -------------------------------------------------
# Heatmap Grids for q at the endpoint
  
plot <- df %>%
  ggplot(aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_q)) +
    geom_tile(data = df %>% filter(is.na(end_q)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = c("white", "lightblue", "skyblue", "dodgerblue2", "blue", "navyblue", "midnightblue", "black"), 
      values = scales::rescale(c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.75, 1.0)),  
      limits = c(0, 1.0),
      breaks = c(0.0, 0.25, 0.5, 0.75, 1.0)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "q endpoint"
    ) +
    facet_grid(p_ordered ~ P_I_ordered, labeller = label_parsed) +
    scale_y_discrete(
      limits = c("0", "0.2", "0.4", "0.6", "0.8", "1"),
      breaks = c("0", "1"),
      labels = c("0", "1")
    ) +
    scale_x_discrete(
      breaks = levels(factor(df$alpha))
    ) +
    custom_theme()
  
  file_name <- file.path(output_dir, "heatmap_endq_3.png")
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  



