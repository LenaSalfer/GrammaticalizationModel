# ---------------------------------------
# Heatmaps for parameter set 1
# ---------------------------------------

library(ggplot2)
library(tidyverse)
library(scales)  
library(viridis)



# Load data
df <- read_csv("Data/heatmap_data/heatmap_set1.csv")

# Define output directory
# AI help
output_dir <- "Data_Analysis/Simulation_Analysis/Simulation_Plots/Heatmaps/heatmaps_set1"



# Define a custom theme.
custom_theme <- function() {
  theme_light() +
    theme(
      plot.title = element_text(size = 18, face = "bold"),
      plot.subtitle = element_text(size = 16),
      axis.title.x = element_text(size = 16, margin = margin(t = 10)),
      axis.title.y = element_text(size = 16, margin = margin(r = 15)),
      axis.text.x = element_text(size = 12),
      axis.text.y = element_text(size = 12),
      legend.title = element_text(size = 16, margin = margin(b = 10)),
      legend.text = element_text(size = 14),
      legend.key.size = unit(0.8, "cm"),
      strip.background = element_rect(fill = "white", color = "black"),
      strip.text = element_text(size = 14, color = "black"),
      strip.text.x = element_text(angle = 0, hjust = 0.5, size = 12),
      strip.text.y = element_text(angle = 270, hjust = 0.5, size = 12)
    )
}


# --------------------------------------------------
# Creating the Heatmap Grids

# Heatmaps: ambiguity & alpha
# Grid for gricean limit & theta
# --------------------------------------------------


df <- df %>%
  filter(theta %in% c(1, 50, 100, 500, 1000, 5000))



# -------------------------------------------------
# Heatmap Grids for grammtaicalization speed

# Modifying the data so that extremely high speed values are colored differently in the plot
# AI help
df_mod <- df %>%
  mutate(
    speed_flag = case_when(
      is.na(speed)   ~ "NA",           # Original NA values remain NA
      speed > 200     ~ "out_of_range", # Mark out-of-range values
      TRUE           ~ "in_range"      # Values within the valid range
    ),
    speed_in_range = if_else(speed_flag == "in_range", speed, NA_real_)
  )



max_age_values <- unique(df_mod$max_age)


# Create heatmap grid for each value of max_age
# AI help for iterating over the max_age values and saving each heatmap
plots <- purrr::map(max_age_values, function(age) {

  df_filtered <- df_mod %>% filter(max_age == age)
  
  plot <- ggplot(df_filtered, aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(data = df_filtered %>% filter(speed_flag == "in_range"),
              aes(fill = speed_in_range)) +
    geom_tile(data = df_filtered %>% filter(is.na(speed)),
              fill = "#D3D8E0") +
    geom_tile(data = df_filtered %>% filter(speed_flag == "out_of_range"),
              fill = "darkred") +
    scale_fill_gradientn(
      colors = rev(heat.colors(5)),
      values = scales::rescale(c(1, 25, 40, 60, 100)),
      limits = c(1, 200),
      trans = "log",
      breaks = c(1, 10, 100)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "Speed"
    ) +
    facet_grid(
      theta ~ gricean_cap,
      labeller = labeller(
        theta = function(x) paste("θ =", x), #AI help
        gricean_cap = function(x) paste("ω =", x) #AI help
      )) +
    scale_y_discrete(limits = c("0", "0.2", "0.4", "0.6", "0.8", "1")) +
    theme(strip.text = element_text(face = "bold"))+
    custom_theme()
  
  # Save the plot 
  file_name <- file.path(output_dir, paste0("heatmap_speed_", age, "_1.png"))
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  
})




# -------------------------------------------------
# Heatmap Grids for UP_ratio at the endpoint


plots <- purrr::map(max_age_values, function(age) {

  df <- df %>% filter(max_age == age)
  
  plot <- ggplot(df, aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_UP_ratio)) +
    geom_tile(data = df %>% filter(is.na(end_UP_ratio)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = rev(plasma(17)),
      values = scales::rescale(c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20, 25, 30, 40, 50)),
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "UP ratio"
    ) +
    facet_grid(
      theta ~ gricean_cap,
      labeller = labeller(
        theta = function(x) paste("θ =", x),
        gricean_cap = function(x) paste("ω =", x)
      )) +
    scale_y_discrete(limits = c("0", "0.2", "0.4", "0.6", "0.8", "1")) +
    theme(strip.text = element_text(face = "bold"))+
    custom_theme()
  

  file_name <- file.path(output_dir, paste0("heatmap_UPratio_", age, "_1.png"))
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  
})



# -------------------------------------------------
# Heatmap Grids for p at the endpoint


plots <- purrr::map(max_age_values, function(age) {
  df <- df %>% filter(max_age == age)
  
  plot <- ggplot(df, aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_p)) +
    geom_tile(data = df %>% filter(is.na(end_p)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = c("white", "#FFCCCC", "#FF9999", "#FF6666", "#FF3333", "#DC143C", "#B22222", "#8B0000"),
      values = scales::rescale(c(0, 0.05, 0.1, 0.3, 0.3, 0.5, 0.7, 1.0)), 
      limits = c(0, 0.7),
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "p endpoint"
    ) +
    facet_grid(
      theta ~ gricean_cap,
      labeller = labeller(
        theta = function(x) paste("θ =", x),
        gricean_cap = function(x) paste("ω =", x)
      )) +
    scale_y_discrete(limits = c("0", "0.2", "0.4", "0.6", "0.8", "1")) +
    theme(strip.text = element_text(face = "bold"))+
    custom_theme()
  
  file_name <- file.path(output_dir, paste0("heatmap_endp_", age, "_1.png"))
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  
})



# -------------------------------------------------
# Heatmap Grids for q at the endpoint

plots <- purrr::map(max_age_values, function(age) {
  df <- df %>% filter(max_age == age)
  
  plot <- ggplot(df, aes(x = factor(alpha), y = factor(ambiguity))) +
    geom_tile(aes(fill = end_q)) +
    geom_tile(data = df %>% filter(is.na(end_q)),
              fill = "#D3D8E0") +
    scale_fill_gradientn(
      colors = c("white", "lightblue", "skyblue", "dodgerblue2", "blue", "navyblue", "midnightblue", "black"), 
      values = scales::rescale(c(0, 0.02, 0.5, 0.15, 0.3, 0.5, 0.7, 1.0)),  
      limits = c(0, 0.5),)
    ) +
    labs(
      x = expression(alpha),
      y = "ambiguity",
      fill = "q endpoint"
    ) +
    facet_grid(
      theta ~ gricean_cap,
      labeller = labeller(
        theta = function(x) paste("θ =", x),
        gricean_cap = function(x) paste("ω =", x)
      )) +
    scale_y_discrete(limits = c("0", "0.2", "0.4", "0.6", "0.8", "1")) +
    theme(strip.text = element_text(face = "bold"))+
    custom_theme()
  
  file_name <- file.path(output_dir, paste0("heatmap_endq_", age, "_1.png"))
  ggsave(filename = file_name, plot = plot, width = 10, height = 10)
  
})




