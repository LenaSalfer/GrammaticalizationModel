# ------------------------------------
# Prepare the processed data
# For the creation of heatmaps
# ------------------------------------
# ---> Run this script for all three parameter sets!


library(tidyverse)


# Define the directories
# AI help
input_dir <- "Data/processed/parameter_set3"
# ---> Adjust the filename!


# List all files from the input directory
# AI help
files <- list.files(
  path = input_dir, 
  pattern = "\\.csv$",  
  recursive = TRUE, 
  full.names = TRUE
)


# Combine all files into one dataframe
df_combined <- files %>%
  map_dfr(read_csv, show_col_type = FALSE)



# create a dataframe for all the parameter combinations in df_combined
df_parameter_combinations <- distinct(df_combined, max_age, alpha, ambiguity, p, theta, P_I, max_gamma, gricean_cap)



# Goal: Calculate means for the results of every parameter combination
# AI help: Handling lapply correctly 
result_list <- lapply(1:nrow(df_parameter_combinations), function(i) {
  
  # Get the current row parameters
  current_row <- df_parameter_combinations[i, ]
  
  # Filter data for the current row's parameters
  filtered_df <- df_combined %>%
    filter(
      max_age == current_row$max_age,
      alpha == current_row$alpha,
      ambiguity == current_row$ambiguity,
      p == current_row$p,
      theta == current_row$theta,
      P_I == current_row$P_I,
      max_gamma == current_row$max_gamma,
      gricean_cap == current_row$gricean_cap
    )
  
  # Calculate the mean over all simulations & count NAs for the following measures
  mean_values <- filtered_df %>%
    summarize(
      NA_midpoint_time = sum(is.na(midpoint_time)),
      midpoint_time = mean(midpoint_time, na.rm = TRUE),
      NA_endpoint_time = sum(is.na(endpoint_time)),
      endpoint_time = mean(endpoint_time, na.rm = TRUE),
      NA_mid_p = sum(is.na(mid_p)),
      mid_p = mean(mid_p, na.rm = TRUE),
      NA_end_p = sum(is.na(end_p)),
      end_p = mean(end_p, na.rm = TRUE),
      NA_mid_q = sum(is.na(mid_q)),
      mid_q = mean(mid_q, na.rm = TRUE),
      NA_end_q = sum(is.na(end_q)),
      end_q = mean(end_q, na.rm = TRUE),
      NA_speed = sum(is.na(speed)),
      speed = mean(speed, na.rm = TRUE),
      UP_new_max = mean(UP_new_max, na.rm = TRUE),
      NA_mid_UP_ratio = sum(is.na(mid_UP_ratio)),
      mid_UP_ratio = mean(mid_UP_ratio, na.rm = TRUE),
      NA_end_UP_ratio = sum(is.na(end_UP_ratio)),
      end_UP_ratio = mean(end_UP_ratio, na.rm = TRUE)
    )
  
  # Return the results as a data frame with the current row's parameters
  return(cbind(current_row, mean_values))
})


# Create the final dataframe
result_list %>% 
  bind_rows() %>%
  arrange(max_age, alpha, ambiguity) %>%
  as_tibble() -> df_means

# Save the final dataframe in a csv file
write_csv(df_means, "Data/heatmap_data/heatmap_set3.csv")
# ---> Adjust the filename!
