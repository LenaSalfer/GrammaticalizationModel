# ---------------------------------------
# Graphical Analysis of the corpus data
# ---------------------------------------

library(tidyverse)
library(ggplot2)



# ---------------------------------------
# 1. Prepare the corpus data
# ---------------------------------------

# Load the corpus data
df_eebo <- read_delim("Data_Analysis/Corpus_Analysis/EEBO_data.csv", delim = ";")
df_coha <- read_delim("Data_Analysis/Corpus_Analysis/COHA_data.csv", delim = ";")


# Transform the data
df_eebo <- data.frame(t(df_eebo[-1]))
df_eebo <- rownames_to_column(df_eebo, var = "year")
colnames(df_eebo) <- c("year", "NP", "VERB", "PASSIVE", "IT", "ALTERNATIVES", "GONNA",
                       "PERCEPTIVE_VERB", "COGNITIVE_VERB", "DESIDERATIVE_VERB", "EMOTIVE_VERB")

df_coha <- data.frame(t(df_coha[-1]))
df_coha <- rownames_to_column(df_coha, var = "year")
colnames(df_coha) <- c("year", "NP", "VERB", "PASSIVE", "IT", "ALTERNATIVES", "GONNA",
                       "PERCEPTIVE_VERB", "COGNITIVE_VERB", "DESIDERATIVE_VERB", "EMOTIVE_VERB")


# Join the data into one df
df_corpora <- bind_rows(df_eebo, df_coha)


# Add NA values for the years not covered by the corpus data to make plotting over the whole time span easier
years <- c(1700, 1710, 1720, 1730, 1740, 1750, 1760, 1770, 1780, 1790, 1800, 1810)

df_corpora <- df_corpora %>%
  complete(year = as.character(years),
           fill = list(
             NP = NA, 
             VERB = NA, 
             PASSIVE = NA, 
             IT = NA,
             ALTERNATIVES = NA, 
             GONNA = NA,
             PERCEPTIVE_VERB = NA, 
             COGNITIVE_VERB = NA, 
             DESIDERATIVE_VERB = NA, 
             EMOTIVE_VERB = NA
           )) %>% arrange(year)



# Calculate measures for the analysis
df_relative <- df_corpora %>%
  mutate(VERB = VERB - PASSIVE) %>%
  # Calculate relative frequencies
  mutate( 
    total = NP + VERB + PASSIVE + IT + GONNA,
    old_rel = if_else(total == 0, 0, NP / total),
    bridge_rel = if_else(total == 0, 0, VERB / total),
    new_rel = if_else(total == 0, 0, (PASSIVE + IT + GONNA) / total),
  ) %>%
  # Calculate new categories for comparisons & their relative frequencies
  mutate(
    total_futures = VERB + PASSIVE + GONNA + IT + ALTERNATIVES,
    going_to_future = VERB + PASSIVE + GONNA + IT,
    going_to_future_rel = going_to_future/total_futures,
    alt_futures_rel = ALTERNATIVES/total_futures
  )





# ---------------------------------------
# 2. Plotting
# ---------------------------------------


# Create a custom theme for the plots
custom_theme <- function() {
  theme_minimal() +
    theme(plot.title = element_text(size=28),
        legend.title = element_text(size=22),
        legend.text = element_text(size=18),
        axis.title.x = element_text(size=17, margin = margin(t = 10)),   
        axis.title.y = element_text(size=17, margin = margin(r = 15)), 
        axis.text.x = element_text(size=15),    
        axis.text.y = element_text(size=15),
        legend.key.size = unit(0.8, "cm")
  ) 
}


# Relative Plots

df_relative %>% 
  select(year, old_rel, bridge_rel, new_rel) %>%
  pivot_longer(cols = c(old_rel, bridge_rel, new_rel), names_to = "usage_pattern", values_to = "frequency") %>%
  ggplot(aes(x = as.numeric(year), y = frequency, color = usage_pattern, group = usage_pattern)) +
  annotate("rect", xmin = 1695, xmax = 1815, ymin = -Inf, ymax = Inf, fill = "gray", alpha = 0.2) +
  geom_vline(xintercept = 1695, linetype = "dashed") +
  geom_vline(xintercept = 1815, linetype = "dashed") +
  geom_point(size = 3) +
  geom_line(size = 1.2) +
  scale_color_manual(
    name = "",
    breaks = c("old_rel", "bridge_rel", "new_rel"),
    values = c("old_rel" = "#FF0000FF", "bridge_rel" = "#aa00fffc", "new_rel" = "#0500ffff"),
    labels = c("old_rel" = "going to + NP", "bridge_rel" = "going to + infinitive", "new_rel" = "going to + passive & gonna")
  ) +
  scale_x_continuous(breaks = seq(1500, 2000, by = 50)) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  theme_minimal() +
  custom_theme() +
  theme(legend.position = "top") +
  labs(x = "year", y = "relative frequency") -> figure29

ggsave("Data_Analysis/Corpus_Analysis/Corpus_Plots/figure29.png", plot = figure29, bg = "white", height=6, width=9)



df_relative %>% 
  select(year, going_to_future_rel, alt_futures_rel) %>%
  pivot_longer(cols = c(going_to_future_rel, alt_futures_rel), names_to = "usage_pattern", values_to = "frequency") %>%
  ggplot(aes(x = as.numeric(year), y = frequency, color = usage_pattern, group = usage_pattern)) +
  annotate("rect", xmin = 1695, xmax = 1815, ymin = -Inf, ymax = Inf, fill = "gray", alpha = 0.2) +
  geom_vline(xintercept = 1695, linetype = "dashed") +
  geom_vline(xintercept = 1815, linetype = "dashed") +
  geom_point(size = 3) +
  geom_line(size = 1.2) +
  scale_color_manual(
    name = "",
    breaks = c("going_to_future_rel", "alt_futures_rel"),
    values = c("going_to_future_rel" = "#0500ffff", "alt_futures_rel" = "#33a1ffff"),
    labels = c("going_to_future_rel" = "going to", "alt_futures_rel" = "will, shall, 'll")
  ) +
  scale_x_continuous(breaks = seq(1500, 2000, by = 50)) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  theme_minimal() +
  custom_theme() +
  theme(legend.position = "top") +
  labs(x = "year", y = "relative frequency") -> figure32

ggsave("Data_Analysis/Corpus_Analysis/Corpus_Plots/figure32.png", plot = figure32, bg = "white", height=6, width=9)



df_relative %>%
  select(year, NP, VERB, PASSIVE, IT) %>%
  filter(year < 1700) %>%
  pivot_longer(cols = c(NP, VERB, PASSIVE, IT), names_to = "usage_pattern", values_to = "frequency") %>%
  ggplot(aes(x = as.numeric(year), y = frequency, color = usage_pattern, group = usage_pattern)) +
  geom_point(size = 3) +
  geom_line(size = 1.2) +
  scale_color_manual(
    name = "",
    breaks = c("NP", "VERB", "PASSIVE", "IT"),
    values = c(
      "NP" = "#FF0000FF",
      "VERB" = "#aa00fffc",
      "PASSIVE" = "#3733ffff",
      "IT" = "#000099ff"
    ),
    labels = c(
      "NP" = "going to + NP",
      "VERB" = "going to + infinitive",
      "PASSIVE" = "going to + passive",
      "IT" = "it + be going to"
    )
  ) +
  scale_x_continuous(breaks = seq(1500, 1650, by = 50)) +
  theme_minimal() +
  custom_theme() +
  theme(legend.position = "top") +
  guides(color = guide_legend(nrow = 2, byrow = TRUE)) +
  labs(x = "year", y = "frequency per million words") -> figure26

ggsave("Data_Analysis/Corpus_Analysis/Corpus_Plots/figure26.png", plot = figure26, bg = "white", height=6, width=9)




df_relative %>%
  select(year, NP, VERB, PASSIVE, IT, GONNA) %>%
  filter(year > 1810) %>%
  pivot_longer(cols = c(NP, VERB, PASSIVE, IT, GONNA), names_to = "usage_pattern", values_to = "frequency") %>%
  ggplot(aes(x = as.numeric(year), y = frequency, color = usage_pattern, group = usage_pattern)) +
  geom_point(size = 3) +
  geom_line(size = 1.2) +
  scale_color_manual(
    name = "",
    breaks = c("NP", "VERB", "PASSIVE", "IT", "GONNA"),
    values = c(
      "NP" = "#FF0000FF",
      "VERB" = "#aa00fffc",
      "PASSIVE" = "#3733ffff",
      "IT" = "#000099ff",
      "GONNA" = "black"
    ),
    labels = c(
      "NP" = "going to + NP",
      "VERB" = "going to + infinitive",
      "PASSIVE" = "going to + passive",
      "IT" = "it + be going to",
      "GONNA" = "gonna"
    )
  ) +
  scale_x_continuous(breaks = seq(1850, 2000, by = 50)) +
  theme_minimal() +
  custom_theme() +
  theme(legend.position = "top") +
  guides(color = guide_legend(nrow = 2, byrow = TRUE)) +
  labs(x = "year", y = "frequency per million words") -> figure27

ggsave("Data_Analysis/Corpus_Analysis/Corpus_Plots/figure27.png", plot = figure27, bg = "white", height=6, width=9)




df_relative %>% 
  select(year, going_to_future, ALTERNATIVES) %>%
  pivot_longer(cols = c(going_to_future, ALTERNATIVES), names_to = "usage_pattern", values_to = "frequency") %>%
  ggplot(aes(x = as.numeric(year), y = frequency, color = usage_pattern, group = usage_pattern)) +
  geom_point(size = 3) +
  geom_line(linewidth = 1.2) +
  annotate("rect", xmin = 1695, xmax = 1815, ymin = -Inf, ymax = Inf, fill = "gray", alpha = 0.2) +
  geom_vline(xintercept = 1695, linetype = "dashed") +
  geom_vline(xintercept = 1815, linetype = "dashed") +
  scale_color_manual(
    name = "",
    breaks = c("going_to_future", "ALTERNATIVES"),
    values = c("going_to_future" = "#0500ffff", "ALTERNATIVES" = "#33a1ffff"),
    labels = c("going_to_future" = "going to", "ALTERNATIVES" = "will, shall, 'll")
  ) +
  scale_x_continuous(breaks = seq(1500, 2000, by = 50)) +
  theme_minimal() +
  custom_theme() +
  theme(legend.position = "top") +
  labs(x = "year", y = "frequency per million words") -> figure28

ggsave("Data_Analysis/Corpus_Analysis/Corpus_Plots/figure28.png", plot = figure28, bg = "white", height=6, width=9)



